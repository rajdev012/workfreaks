#![cfg_attr(feature = "release", windows_subsystem = "windows")]

fn main() {
    cli::init();
}
