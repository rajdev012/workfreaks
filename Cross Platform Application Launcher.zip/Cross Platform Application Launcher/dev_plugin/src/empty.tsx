import { ReactElement } from "react";

export default function DetailView(): ReactElement {
    return <></>
}
