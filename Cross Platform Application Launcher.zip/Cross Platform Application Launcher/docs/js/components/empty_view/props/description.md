Optional description to display in the middle of the view under `title`.
Use it to give longer explanation for empty view