Inline is a root component used with `inline-view` entrypoint type.
Displayed right under search bar in main view