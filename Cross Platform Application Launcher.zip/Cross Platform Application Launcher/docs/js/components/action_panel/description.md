Actions are one of the ways to add interactivity to the UI.
Action Panel is a popup at the right bottom of the window that contains all Actions