List of tags with a title
Tags can be used as clickable button