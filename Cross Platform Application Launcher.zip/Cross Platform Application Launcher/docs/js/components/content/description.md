A container for a set of non-interactable components.
Used in a variety of places like [Detail]($COMPONENT$__DETAIL__), [Inline]($COMPONENT$__INLINE__) and [GridItem]($COMPONENT$__GRID_ITEM__).
By utilizing the power of React the content can also be made dynamic