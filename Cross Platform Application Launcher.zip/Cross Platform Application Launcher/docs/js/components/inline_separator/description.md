Separates inline content sections.
Separators are present even when not specified explicitly.
Specifying separator explicitly allows to define custom icon