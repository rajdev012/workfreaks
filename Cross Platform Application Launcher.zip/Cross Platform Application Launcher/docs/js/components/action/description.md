Adds action entry to the action panel.
Can be executed either by clicking the button or by pressing the shortcut