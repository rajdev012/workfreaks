mod ui;
mod theme;
mod views;
mod components;

pub fn start_management_client() {
    ui::run();
}
