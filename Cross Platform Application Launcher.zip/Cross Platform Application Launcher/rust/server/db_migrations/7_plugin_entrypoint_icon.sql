ALTER TABLE plugin_entrypoint ADD COLUMN icon_path TEXT DEFAULT NULL;
