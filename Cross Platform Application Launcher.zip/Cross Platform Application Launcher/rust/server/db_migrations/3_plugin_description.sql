ALTER TABLE plugin ADD COLUMN description TEXT NOT NULL DEFAULT '';

ALTER TABLE plugin_entrypoint ADD COLUMN description TEXT NOT NULL DEFAULT '';
